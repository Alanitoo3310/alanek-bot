const { Client, GatewayIntentBits } = require("discord.js");
const { loadEvents } = require("./handler");
const { connection } = require("./src/utils/database");

const client  = new Client({ intents: Object.keys(GatewayIntentBits).map((a) =>{ return GatewayIntentBits[a] }), });

require("dotenv").config();

connection.connect(err => {
    console.log(`Połączono z bazą danych!`);
});

loadEvents(client);

client.login(process.env.TOKEN);