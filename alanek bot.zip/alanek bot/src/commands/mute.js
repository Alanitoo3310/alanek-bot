const { SlashCommandBuilder, Interaction, Client, PermissionFlagsBits } = require("discord.js");

const MUTE_ROLE_ID = "1203781794143404065";

module.exports = {
    data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Komenda do wyciszania użytkownika")
    .addUserOption(option => option.setName("target").setDescription("Użytkownik").setRequired(true))
    .addStringOption(option => option.setName("time").setDescription("Czas wyciszenia (s - sekundy, m - minuty, h - godziny, d - dni, i - perm)"))
    .addStringOption(option => option.setName("reason").setDescription("powód")),
    /**
     * 
     * @param {Interaction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });

        if(!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return interaction.editReply({ content: "Nie posiadasz permisji" });

        const target = await interaction.guild.members.fetch(interaction.options.getUser("target").id);

        if(!target) return interaction.editReply({ content: "Tego użytkownika nie ma na serwerze" });

        const time = interaction.options?.getString("time") || '0i';

        if (time.length < 2) return interaction.editReply({ content: "Błędny format czasu" });

        let number = time.substring(0, time.length -1);

        if(isNaN(number)) return interaction.editReply({ content: "Musisz podac numer" })

        number = parseInt(number);

        const unit = time.substring(time.length -1);
        let muteTime = 0;

        switch(unit.toLowerCase()) {
            case "s":
                muteTime = number;
                break;
            case "m":
                muteTime = number * 60;
                break;
            case "h":
                muteTime = number * 60 * 60;
                break;
            case "d":
                muteTime = number * 60 * 60 * 24;
                break;
            case "i":
                muteTime = -1;
                break;
            default:
                return interaction.editReply({ content: "Podaj poprawną jednostke czasu" });
        }

        const reason = interaction.options?.getString("reason") || "Brak powodu";

        const muteRole = interaction.guild.roles.cache.get(MUTE_ROLE_ID);

        if(!muteRole) return interaction.editReply({ content: "Rola mute nie istnieje" });

        target.roles.add(muteRole);

        if(muteTime !== -1) {
            setTimeout(() => {
                if(!target.roles.cache.has(MUTE_ROLE_ID)) return;
    
                target.roles.remove(muteRole);
            }, 1000 * muteTime);
        }

        interaction.channel.send({ content: `:mute: Wyciszono użytkownika <@${target.id}> za \`${reason}\`` });

        return interaction.editReply({ content: "Pomyślnie wykonano operacje" })
    }
}