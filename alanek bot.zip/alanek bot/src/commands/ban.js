const { SlashCommandBuilder, Interaction, Client, PermissionFlagsBits } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Komenda do banowania użytkownika")
    .addUserOption(option => option.setName("target").setDescription("Użytkownik").setRequired(true))
    .addStringOption(option => option.setName("reason").setDescription("Powód")),
    /**
     * 
     * @param {Interaction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });

        if(!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) return interaction.editReply({ content: "Nie posiadasz uprawnień" });

        const target = await interaction.guild.members.fetch(interaction.options.getUser("target").id);

        if(!target) return interaction.editReply({ content: "Tego użytkownika aktualnie nie ma na serwerze" });

        const rolesPostition = {
            target: target.roles.highest.position,
            user: interaction.member.roles.highest.position,
            bot: interaction.guild.members.me.roles.highest.position
        }

        if(rolesPostition.user < rolesPostition.target) {
            return interaction.editReply({ content: "Ten użytkownik ma wyższą bądź tą samą range" });
        }

        if(rolesPostition.bot < rolesPostition.target) {
            return interaction.editReply({ content: "Bot nie ma permisji" })
        }

        const reason = interaction.options?.getString("reason") || 'Brak powodu';

        target.ban({ reason: reason });

        return interaction.editReply({ content: "Zbanowano użytkownika" })
    }
}