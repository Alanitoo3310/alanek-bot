const mysql = require("mysql");

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'alanek_bot_db',
    charset: 'utf8mb4'
});

/**
 * 
 * @param {String} tableName 
 * @param {String} restStatement 
 * @returns {Number}
 */
async function countRows(tableName, restStatement) {
    const sql = "SELECT COUNT(*) AS rowCount FROM `" + tableName + "` " + restStatement;

    const res = await new Promise((resolve, reject) => {
        connection.query(sql, (err, result) => {
            if(err) {
                reject(err);
                return;
            } else {
                resolve(result);
            }
        })
    });

    return (parseInt(res[0].rowCount));
}

/**
 * 
 * @param {String} statement 
 * @returns {RowDataPacket}
 */
async function getQuery(statement) {
    const sql = statement;

    const res = await new Promise((resolve, reject) => {
        connection.query(sql, (err, result) => {
            if(err) {
                reject(err);
                return;
            } else {
                resolve(result);
            }
        })
    });

    return res;
}

/**
 * 
 * @param {String} statement 
 */
function executeUpdate(statement) {
    connection.query(statement, (err, result) => { });
}

module.exports = {
    countRows,
    getQuery,
    executeUpdate,
    connection: connection
}