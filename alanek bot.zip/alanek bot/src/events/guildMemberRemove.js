const { Client, GuildMember } = require("discord.js");
const { countRows, executeUpdate } = require("../utils/database")

module.exports = {
    name: "guildMemberRemove",
    /**
     * 
     * @param {Client} client 
     * @param {GuildMember} member 
     */
    async execute(client, member) {
        const rows = await countRows("roles_history", "WHERE `userId` = '" + member.id + "'");

        const rolesIds = Array.from(member.roles.cache.keys());

        RolesIds.pop();

        if(rows === 0) {
            executeUpdate("INSERT INTO `roles_history` VALUES('" + member.id + "', '" + rolesIds.join(";") + "')");
        } else {
            executeUpdate("UPDATE `roles_history` SET `roles`= '"+ rolesIds.join(";") + "'WHERE `userId='" + member.id + "'")
        }
    }
}