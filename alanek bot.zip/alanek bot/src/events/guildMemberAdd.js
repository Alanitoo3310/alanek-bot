const { Client, GuildMember } = require("discord.js");
const { countRows, getQuery } = require("../utils/database");

module.exports = {
    name: "guildMemberAdd",
    /**
     * 
     * @param {Client} client 
     * @param {GuildMember} member 
     */
    async execute(client, member) {
        const rows = await countRows("roles_history", "WHERE `userId`='" + member.id + "'");

        if(rows === 0) return

        const query = await getQuery("SELECT * FROM `roles_history` WHERE `userId`='" + member.id + "'");

        const roles = query[0].roles.split(";");

        for(const roleId of roles) {
            const role = member.guild.roles.cache.get(roleId);

            if(!role) continue;

            member.roles.add(role);
        }
    }
}