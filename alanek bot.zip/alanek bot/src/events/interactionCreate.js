const { Client, Interaction } = require("discord.js");

const INTERACTION_IDS = {
    VERIFY: 'verify'
}

module.exports ={
    name: "interactionCreate",
    /**
     * 
     * @param {Client} client 
     * @param {Interaction} interaction 
     */
    async execute(client, interaction) {
        if(!interaction.isCommand()) return;

        if(!client.commands.has(interaction.commandName)) return;

        const interactionFunction = client.commands.get(interaction.commandName);

        interactionFunction(interaction, client);
    },
    INTERACTION_IDS: INTERACTION_IDS
}